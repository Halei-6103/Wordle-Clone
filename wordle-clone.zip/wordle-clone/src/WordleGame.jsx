import React, { useState, useEffect } from "react";
import "./style.css"; // Import styles

const WORDS_URL = "https://raw.githubusercontent.com/dwyl/english-words/master/words_alpha.txt"; 

const WordleGame = () => {
  const [wordList, setWordList] = useState([]);
  const [word, setWord] = useState("");
  const [guesses, setGuesses] = useState([]);
  const [input, setInput] = useState("");
  const [attempts, setAttempts] = useState(6);

  useEffect(() => {
    fetch(WORDS_URL)
      .then((response) => response.text())
      .then((text) => {
        const wordsArray = text
          .split("\n")
          .map(word => word.trim().toLowerCase())
          .filter(word => word.length === 5);
        setWordList(wordsArray);
        setWord(wordsArray[Math.floor(Math.random() * wordsArray.length)]);
      })
      .catch(error => console.error("Error loading words:", error));
  }, []);

  const handleGuess = () => {
    if (input.length !== 5) {
      alert("Enter a 5-letter word!");
      return;
    }

    if (!wordList.includes(input)) {
      alert("That's not a valid word. Try again!");
      return;
    }

    let feedback = new Array(5).fill(null);
    let tempWord = word.split("");

    input.split("").forEach((char, index) => {
      if (char === word[index]) {
        feedback[index] = { letter: char, status: "correct" };
        tempWord[index] = null;
      }
    });

    input.split("").forEach((char, index) => {
      if (!feedback[index] && tempWord.includes(char)) {
        feedback[index] = { letter: char, status: "misplaced" };
        tempWord[tempWord.indexOf(char)] = null;
      }
    });

    feedback = feedback.map((item, index) =>
      item ? item : { letter: input[index], status: "empty" }
    );

    setGuesses([...guesses, feedback]);
    setInput("");
    setAttempts(attempts - 1);

    if (input === word) {
      alert(`🎉 You guessed the word: ${word}`);
    } else if (attempts - 1 === 0) {
      alert(`😢 Game Over! The word was: ${word}`);
    }
  };

  const handleNewGame = () => {
    setGuesses([]);
    setInput("");
    setAttempts(6);
    setWord(wordList[Math.floor(Math.random() * wordList.length)]);
  };

  return (
    <div className="game-wrapper">
      <h1 className="game-title">Wordle Clone</h1>
      <div className="game-container">
        <h2>Attempts Left: {attempts}</h2>
        <div className="wordle-grid">
          {[...Array(6)].map((_, rowIndex) => (
            <div key={rowIndex} className="word-row">
              {guesses[rowIndex]
                ? guesses[rowIndex].map((item, colIndex) => (
                    <div key={colIndex} className={`letter-box ${item.status}`}>
                      {item.letter.toUpperCase()}
                    </div>
                  ))
                : [...Array(5)].map((_, colIndex) => (
                    <div key={colIndex} className="letter-box empty">_</div>
                  ))}
            </div>
          ))}
        </div>
      </div>
      {attempts > 0 ? (
        <div className="input-container">
          <input
            type="text"
            value={input}
            maxLength={5}
            onChange={(e) => setInput(e.target.value.toLowerCase())}
          />
          <button onClick={handleGuess}>Submit</button>
        </div>
      ) : (
        <div className="input-container">
          <p className="game-over">Game Over! The word was: <strong>{word}</strong></p>
          <button onClick={handleNewGame} className="new-word-btn">New Word</button>
        </div>
      )}
    </div>
  );
};

export default WordleGame;
