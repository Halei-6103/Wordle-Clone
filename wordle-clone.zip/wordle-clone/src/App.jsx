import React from "react";
import WordleGame from "./WordleGame"; // Ensure this file exists

function App() {
  return (
    <div>
      <WordleGame />
    </div>
  );
}

export default App;
